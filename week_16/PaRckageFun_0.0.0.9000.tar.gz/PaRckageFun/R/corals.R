#' The toy corals dataset
#'
#' A dataset containing randomly selected coral
#'
#' @format A tibble with 3 rows and 2 columns
#' \describe{
#'  \item{coral}{Character id of the coral}
#'  \item{healthy}{Logical value representing whether the coral is healthy or not}
#' }
#' @source Randomly generated data
"corals"