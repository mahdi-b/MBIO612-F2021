#' Add together two numbers
#'
#' Slighly longer description
#'
#' Some longer description about your function and what it does goes here.
#' this description can be as detailed as you need it to be.
#'
#' @param x A number
#' @param y A number
#' @return The sum of \code{x} and \code{y} as a tibble
#' @import dplyr
#' @export
#' @examples
#' add(1, 1)
#' add(10, 1)
add <- function(x, y) {
  tibble(result = x + y)
}
