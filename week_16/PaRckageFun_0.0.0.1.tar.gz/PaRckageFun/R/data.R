#' The toy animals file
#'
#' A dataset containing randomly selected animal files
#'
#' @format A tibble with 5 rows and 2 columns
#' \describe{
#'  \item{animal}{Character values. Either cat, dog or fish}
#'  \item{weight}{Numeric values representing the animal weight in Kg.}
#' }
#' @source Randomly generated data
"animals"